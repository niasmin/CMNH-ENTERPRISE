/* V10.8 Living Buildings: real building IDs and global care simulation state; local room decor is visual only. */
(()=>{'use strict';
const B=window.HealthcareBridge,G=window.HealthcareCore;if(!B||!G)return;
const A='assets/';
const R={
 standard:['ห้องพักมาตรฐาน','room-standard-clean.webp','🛏️'],vip:['ห้องพัก VIP','room-vip-clean.webp','🌷'],
 therapy:['ห้องกายภาพ','room-therapy-clean.webp','🧘'],nurse:['สถานีพยาบาล','room-nurse-station-clean.webp','👩‍⚕️'],
 dining:['ห้องอาหาร','room-dining-clean.webp','🍽️'],activity:['ห้องกิจกรรม','room-activity-clean.webp','🎨'],
 clinic:['ห้องตรวจ','room-clinic-clean.webp','🩺'],feeding:['ห้องดูแลเฉพาะทาง','room-feeding-clean.webp','💗']};
const T={
 ward:[['standard','standard'],['standard','nurse'],['dining','activity']],
 villa:[['vip','vip'],['vip','nurse'],['dining','activity']],
 hospital:[['clinic','feeding'],['standard','nurse'],['therapy','dining']],
 branch:[['standard','clinic'],['nurse','therapy'],['dining','activity']],
 therapy:[['therapy','therapy']],activity:[['activity','activity']],garden:[['activity','dining']],
 homecare:[['clinic','nurse'],['therapy','activity']],lab:[['clinic','feeding']],
 headquarters:[['nurse','activity']]};
const N={ward:'CMNH Nursing Home',villa:'Tranquila Elderly Care',hospital:'Neuro Hospital',branch:'Payap Health Care',homecare:'CMCC Home Care',therapy:'ศูนย์กายภาพ',activity:'ศูนย์กิจกรรม',garden:'สวนพักผ่อน',lab:'ศูนย์วิจัย',headquarters:'สำนักงานใหญ่'};
const ITEMS=[['plant','🪴','ต้นไม้'],['lamp','💡','โคมไฟ'],['chair','🪑','เก้าอี้'],['flowers','💐','ดอกไม้'],['books','📚','หนังสือ'],['bear','🧸','ของตกแต่ง']];
const PEOPLE={rn:['avatar-nurse_blue_01.png','พยาบาล'],pn:['avatar-care_staff_01.png','ผู้ช่วยพยาบาล'],caregiver:['avatar-care_staff_01.png','ผู้ดูแล'],pt:['avatar-therapist.png','นักกายภาพ'],ot:['avatar-therapist.png','นักกิจกรรมบำบัด'],resident:['avatar-resident_man.png','ผู้พักอาศัย']};
const root=document.createElement('div');root.className='he107-overlay he108';root.hidden=true;root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-label','สำรวจอาคารจริง');
root.innerHTML=`<div class="he107-shell"><header class="he107-header"><button id="he108-close" type="button" aria-label="กลับแผนที่">‹</button><div><strong id="he108-title">🏡 อาคาร</strong><small id="he108-summary"></small></div><button id="he108-help" type="button" aria-label="วิธีเล่น">❔</button></header><div class="he107-content"><div id="he108-list" class="he108-list"></div><div class="he107-cutaway" id="he108-building"><div class="he107-roof" id="he108-roof"></div><div id="he108-floors" class="he107-floors"></div><div class="he107-lobby" id="he108-lobby">🌼 พื้นที่ส่วนกลาง · ทางเข้า</div></div><div class="he108-status" id="he108-status"></div><div class="he107-edit" id="he108-edit" hidden><div class="he107-edit-head"><button id="he108-back" type="button">‹ กลับอาคาร</button><strong id="he108-room-title"></strong><span id="he108-count"></span></div><div class="he107-room-scene" id="he108-scene"><img id="he108-bg" alt=""><div class="he107-placements" id="he108-placements"></div></div><p class="he107-instruction" id="he108-instruction">เลือกของตกแต่ง แล้วแตะในห้องเพื่อวาง (ตกแต่งภาพ ไม่หักเงินเกม)</p><div class="he107-items" id="he108-items"></div><div class="he107-edit-actions"><button id="he108-undo" type="button">↶ ย้อนกลับ</button><button id="he108-reset" type="button">🧹 ล้างห้อง</button><button id="he108-done" type="button">✓ บันทึก</button></div></div></div><nav class="he107-nav"><button id="he108-map" type="button">🗺️<span>แผนที่</span></button><button id="he108-rooms" type="button">🏠<span>อาคาร</span></button><button id="he108-build" type="button">🔨<span>ก่อสร้าง</span></button><button id="he108-staff" type="button">👩‍⚕️<span>บุคลากร</span></button></nav><div class="he107-toast" id="he108-toast" role="status" aria-live="polite"></div></div>`;
document.body.append(root);const $=id=>document.getElementById(id);
let bid=null,room=null,choice=null,decor={},toastTimer=null;
function state(){return B.getState();}function key(){return 'he-v108-decor-'+(B.getLocalKey?.()||'guest');}
function load(){try{const obj=JSON.parse(localStorage.getItem(key())||'{}');decor=obj&&typeof obj==='object'&&!Array.isArray(obj)?obj:{};}catch{decor={};}}
function save(){try{localStorage.setItem(key(),JSON.stringify(decor));}catch{toast('บันทึกในเครื่องไม่ได้');}}
function toast(msg){$('he108-toast').textContent=msg;$('he108-toast').classList.add('he107-visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('he108-toast').classList.remove('he107-visible'),2300);}
function building(){return state().buildings.find(b=>String(b.id)===String(bid));}
function roomKey(){return String(bid)+':'+room?.slot;}function placed(){return Array.isArray(decor[roomKey()])?decor[roomKey()]:[];}
function peopleFor(type,idx,s){const roles=type==='therapy'?['pt','caregiver']:type==='hospital'?['rn','pn','resident']:type==='villa'?['caregiver','resident']:type==='ward'?['caregiver','resident','rn']:type==='activity'?['ot','caregiver']:['rn','caregiver'];const eligible=roles.filter(r=>r==='resident'?s.residents>0:(s.staff[r]||0)>0);return eligible.length?PEOPLE[eligible[idx%eligible.length]]:null;}
function capacityInfo(b,s){const cap=G.BUILDINGS[b.type]?.cap||0;const before=s.buildings.filter(x=>x.id!==b.id&&x.id<b.id).reduce((a,x)=>a+(G.BUILDINGS[x.type]?.cap||0),0);return {cap,occupancy:cap?Math.max(0,Math.min(cap,s.residents-before)):0};}
function list(){const s=state(),all=s.buildings;$('he108-list').replaceChildren();for(const b of all){const bt=document.createElement('button');bt.type='button';bt.className='he108-building-chip'+(b.id===bid?' active':'');bt.textContent=`${N[b.type]||G.BUILDINGS[b.type]?.name||b.type} #${b.id}`;bt.onclick=()=>select(b.id);$('he108-list').append(bt);}if(!all.length){$('he108-list').textContent='ยังไม่มีอาคาร — กดก่อสร้างเพื่อเริ่มต้น';}}
function select(id){const s=state(),b=s.buildings.find(x=>String(x.id)===String(id));if(!b){bid=s.buildings[0]?.id??null;if(bid===null){$('he108-building').hidden=true;$('he108-status').textContent='ยังไม่มีอาคารในเกม';return;}return select(bid);}bid=b.id;room=null;choice=null;$('he108-edit').hidden=true;$('he108-building').hidden=false;$('he108-list').hidden=false;$('he108-status').hidden=false;list();render();}
function render(){const s=state(),b=building();if(!b)return;const info=capacityInfo(b,s),name=N[b.type]||G.BUILDINGS[b.type]?.name||b.type;
 $('he108-title').textContent='🏡 '+name;$('he108-summary').textContent=`อาคาร #${b.id} • วันที่ ${s.day} • ${String(s.hour).padStart(2,'0')}:00`;
 $('he108-roof').textContent=`🌿 ${name.toUpperCase()} · #${b.id}`;$('he108-lobby').textContent=b.type==='garden'?'🌳 สวนพักผ่อนและกิจกรรมกลางแจ้ง':'🌼 พื้นที่ส่วนกลาง · ทางเข้าหลัก';
 const floorRoot=$('he108-floors');floorRoot.replaceChildren();const floors=T[b.type]||T.ward;
 for(let f=floors.length-1;f>=0;f--){const floor=document.createElement('section');floor.className='he107-floor';const number=document.createElement('div');number.className='he107-floor-num';number.textContent=(f+1)+'F';floor.append(number);
 floors[f].forEach((id,j)=>{const data=R[id],slot=f+'-'+j,bt=document.createElement('button');bt.type='button';bt.className='he107-room-tile';const bg=document.createElement('img');bg.src=A+data[1];bg.alt='';bg.loading='lazy';const label=document.createElement('span');label.textContent=data[2]+' '+data[0];bt.append(bg,label);
 const person=peopleFor(b.type,f+j,s);if(person){const walker=document.createElement('img');walker.className='he107-walker';walker.src=A+person[0];walker.alt='';walker.setAttribute('aria-hidden','true');walker.style.animationDelay=(-((f+j)*2.2))+'s';bt.append(walker);}bt.onclick=()=>edit({id,slot});floor.append(bt);});floorRoot.append(floor);}
 const totalStaff=Object.values(s.staff).reduce((a,v)=>a+v,0);$('he108-status').textContent=`🛏️ เตียงอาคารนี้ ${info.occupancy}/${info.cap} · 👩‍⚕️ บุคลากรทั้งเครือข่าย ${totalStaff} คน · 💗 คุณภาพชีวิต ${s.wellbeing}%`;
}
function open(id){load();root.hidden=false;document.body.classList.add('he107-open');select(id??bid??state().buildings[0]?.id);}
function close(){root.hidden=true;document.body.classList.remove('he107-open');room=null;choice=null;}
function showFloors(){if(!building()){select(state().buildings[0]?.id);return;}room=null;choice=null;$('he108-edit').hidden=true;$('he108-building').hidden=false;$('he108-list').hidden=false;$('he108-status').hidden=false;render();}
function edit(r){room=r;choice=null;$('he108-building').hidden=true;$('he108-list').hidden=true;$('he108-status').hidden=true;$('he108-edit').hidden=false;const data=R[r.id];$('he108-room-title').textContent=data[2]+' '+data[0];$('he108-bg').src=A+data[1];$('he108-bg').alt=data[0];items();placements();}
function items(){const box=$('he108-items');box.replaceChildren();for(const [id,emoji,name] of ITEMS){const bt=document.createElement('button');bt.type='button';bt.className='he107-item'+(choice===id?' selected':'');bt.innerHTML=`<span>${emoji}</span><small>${name}</small>`;bt.onclick=()=>{choice=id;items();$('he108-instruction').textContent='แตะจุดที่ต้องการวาง '+name;};box.append(bt);}}
function xy(e){const rect=$('he108-scene').getBoundingClientRect();return{x:Math.round(Math.max(7,Math.min(93,100*(e.clientX-rect.left)/rect.width))),y:Math.round(Math.max(12,Math.min(88,100*(e.clientY-rect.top)/rect.height)))};}
function placements(){const box=$('he108-placements');box.replaceChildren();placed().forEach((p,i)=>{const item=ITEMS.find(x=>x[0]===p.id);if(!item)return;const bt=document.createElement('button');bt.type='button';bt.className='he107-placed';bt.style.left=p.x+'%';bt.style.top=p.y+'%';bt.textContent=item[1];bt.setAttribute('aria-label','ย้ายหรือลบ '+item[2]);let down=null;bt.onpointerdown=e=>{e.stopPropagation();down={x:e.clientX,y:e.clientY};bt.setPointerCapture(e.pointerId);};bt.onpointerup=e=>{e.stopPropagation();if(!down)return;const dist=Math.hypot(e.clientX-down.x,e.clientY-down.y);if(dist<9){placed().splice(i,1);toast('ลบของตกแต่งแล้ว');}else Object.assign(placed()[i],xy(e));down=null;save();placements();};box.append(bt);});$('he108-count').textContent=placed().length+'/12';}
$('he108-scene').onclick=e=>{if(!room||e.target.closest('.he107-placed'))return;if(!choice){toast('เลือกของตกแต่งก่อน');return;}if(placed().length>=12){toast('ห้องเต็มแล้ว (12 ชิ้น)');return;}const k=roomKey();if(!decor[k])decor[k]=[];decor[k].push({id:choice,...xy(e)});save();placements();toast('ตกแต่งสำเร็จ ✓');};
$('he108-close').onclick=close;$('he108-map').onclick=close;$('he108-rooms').onclick=showFloors;$('he108-back').onclick=showFloors;$('he108-done').onclick=()=>{save();showFloors();toast('บันทึกการตกแต่งแล้ว ✓');};
$('he108-undo').onclick=()=>{if(placed().length){placed().pop();save();placements();}};
$('he108-reset').onclick=()=>{if(room&&confirm('ลบของตกแต่งในห้องนี้ทั้งหมด?')){decor[roomKey()]=[];save();placements();}};
$('he108-help').onclick=()=>toast('เลือกอาคาร → แตะห้อง → เลือกเฟอร์นิเจอร์ → แตะวาง');
$('he108-build').onclick=()=>{close();window.HealthcareMobile?.open('build');};$('he108-staff').onclick=()=>{close();window.HealthcareMobile?.open('staff');};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!root.hidden){if(room)showFloors();else close();}});
window.addEventListener('healthcare:changed',()=>{if(root.hidden)return;const b=building();if(!b){select(state().buildings[0]?.id);return;}if(!room){list();render();}else $('he108-summary').textContent=`อาคาร #${b.id} • วันที่ ${state().day}`;});
window.HealthcareRooms={open,close,showFloors,version:'10.8',getDecor:()=>JSON.parse(JSON.stringify(decor)),getSelectedBuilding:()=>bid};
})();
