/* V10.3 Visual Master Integration - original art is concept art, not a 3D simulation. */
(() => {
 'use strict';
 const bridge=window.HealthcareBridge, scene=document.getElementById('scene');
 if(!bridge||!scene)return;
 const panel=scene.closest('.panel'),wrap=scene.closest('.canvas-wrap');
 if(!panel||!wrap)return;
 const phases=[
  ['First Care Home','CMNH • ศูนย์ดูแลเริ่มต้น'],
  ['Professional Nursing Center','CMNH • ศูนย์ดูแลมาตรฐานวิชาชีพ'],
  ['Tranquila Premium Senior Living','วิลล่าผู้สูงอายุระดับพรีเมียม'],
  ['Home Care & Daycare','บริการดูแลที่บ้านและศูนย์ดูแลกลางวัน'],
  ['Healthcare Workforce','Payap Health Care • บุคลากร'],
  ['Neuro Hospital','โรงพยาบาลระบบประสาท'],
  ['Healthcare Empire','เครือข่ายธุรกิจสุขภาพครบวงจร']
 ];
 const roomDefs=[['standard','ห้องพักมาตรฐาน'],['vip','ห้อง VIP'],['feeding','ห้อง NG/PEG'],['therapy','ห้องกายภาพ'],['activity','ห้องกิจกรรม'],['dining','ห้องอาหาร'],['nurse-station','Nurse Station'],['clinic','คลินิก OPD']];
 const avatarDefs=[['nurse_blue_01','พยาบาล RN'],['care_staff_01','ผู้ดูแล NA'],['doctor','แพทย์'],['therapist','นักกายภาพ'],['resident_man','ผู้พักอาศัย'],['resident_wheelchair','ผู้ใช้รถเข็น']];
 const thumbMap={ward:'ward',villa:'villa',hospital:'hospital',homecare:'homecare',branch:'branch',lab:'lab',headquarters:'branch',therapy:'ward',activity:'villa',garden:'villa'};
 const header=document.createElement('div');header.className='he-visual-header';header.innerHTML='<h3>🎨 แผนที่ภาพต้นแบบของคุณ</h3><div class="he-visual-modes"><button class="he-vmode" id="he-art-mode" type="button" aria-pressed="true">🖼️ แผนที่ภาพ</button><button class="he-vmode" id="he-sim-mode" type="button" aria-pressed="false">🏗️ แผนที่ก่อสร้างจริง</button></div>';
 wrap.before(header);
 const stage=document.createElement('div');stage.className='he-visual-stage';stage.id='he-art-stage';stage.setAttribute('aria-label','แผนที่ภาพประกอบ Healthcare Empire');
 const image=document.createElement('img');image.id='he-art-image';image.alt='ภาพต้นแบบอาคาร Healthcare Empire';stage.append(image);
 const label=document.createElement('div');label.className='he-phase-label';stage.append(label);
 wrap.before(stage);
 const list=document.createElement('div');list.className='he-phase-list';list.id='he-phase-list';list.setAttribute('aria-label','เลือก Phase ภาพที่ปลดล็อกแล้ว');
 phases.forEach(([title],i)=>{
  const b=document.createElement('button');b.className='he-phase';b.type='button';b.dataset.phase=String(i+1);
  const im=document.createElement('img');im.src=`assets/phase-${i+1}.webp`;im.alt=`ภาพ Phase ${i+1}`;im.loading='lazy';
  const strong=document.createElement('strong');strong.textContent=`Phase ${i+1}`;
  const small=document.createElement('small');small.textContent=title;
  b.append(im,strong,small);b.addEventListener('click',()=>{phase=i+1;drawStage();});list.append(b);
 });stage.after(list);
 const cap=document.createElement('p');cap.className='he-visual-caption';cap.textContent='ภาพจากต้นแบบที่คุณส่งมา • เลือก Phase เพื่อชมอาคาร • กด “แผนที่ก่อสร้างจริง” เพื่อดูอาคารที่สร้างตาม Save และแตะเลือกอาคารได้';list.after(cap);
 const gallery=document.createElement('section');gallery.className='he-gallery';gallery.innerHTML='<h3>🏥 ห้องและสิ่งอำนวยความสะดวกจากต้นแบบ</h3><div class="he-gallery-grid"></div>';
 roomDefs.forEach(([id,title])=>{const card=document.createElement('div');card.className='he-room-card';const img=document.createElement('img');img.src=`assets/room-${id}.webp`;img.alt=title;img.loading='lazy';const name=document.createElement('span');name.textContent=title;card.append(img,name);gallery.querySelector('.he-gallery-grid').append(card);});
 cap.after(gallery);
 const character=document.createElement('section');character.className='he-gallery';character.innerHTML='<h3>👩‍⚕️ ตัวละครและบุคลากร</h3><div class="he-character-strip"></div>';
 avatarDefs.forEach(([id,title])=>{const card=document.createElement('div');card.className='he-character';const img=document.createElement('img');img.src=`assets/avatar-${id}.png`;img.alt=title;img.loading='lazy';const name=document.createElement('small');name.textContent=title;card.append(img,name);character.querySelector('.he-character-strip').append(card);});gallery.after(character);
 let mode='art',phase=Math.max(1,Math.min(7,bridge.getState().chapter-3));
 const pins=[
  {x:47,y:59,name:'CMNH',type:'ward'},
  {x:24,y:25,name:'Tranquila',type:'villa'},
  {x:77,y:23,name:'Neuro Hospital',type:'hospital'},
  {x:17,y:66,name:'Home Care',type:'homecare'},
  {x:83,y:57,name:'PHC Workforce',type:'branch'},
  {x:83,y:83,name:'CM.Derma+',type:'lab'}
 ];
 function pinClick(pin){
  const state=bridge.getState();
  const owned=state.buildings.filter(b=>b.type===pin.type).length;
  const btn=document.querySelector(`[data-building="${pin.type}"]`);
  if(owned){window.alert(`${pin.name}\nมีอาคารประเภทนี้ ${owned} หลังใน Save ปัจจุบัน\nเปิดแผนที่ก่อสร้างจริงเพื่อเลือกอาคารรายหลัง`);}
  else if(btn){btn.scrollIntoView({behavior:'smooth',block:'center'});btn.focus();window.alert(`${pin.name}\nภาพนี้เป็นต้นแบบอ้างอิง ยังไม่ได้ก่อสร้างใน Save ปัจจุบัน\nใช้ปุ่มก่อสร้างที่กำลังเลือกเพื่อเพิ่มอาคาร`);}
  else window.alert(`${pin.name}\nภาพต้นแบบ ยังไม่มีระบบก่อสร้างแยกสำหรับอาคารนี้`);
 }
 function drawStage(){
  const s=bridge.getState();
  if(phase>s.chapter-3)phase=Math.max(1,s.chapter-3);
  const i=phase-1;image.src=i===6?'assets/campus-master.webp':`assets/phase-${phase}.webp`;
  image.alt=`Phase ${phase}: ${phases[i][0]} (ภาพต้นแบบ ไม่ใช่สถานะอาคารจริง)`;
  label.replaceChildren();const strong=document.createElement('strong');strong.textContent=`Phase ${phase} • ${phases[i][0]}`;
  const small=document.createElement('span');small.textContent=`${phases[i][1]} • V${phase+3} • อาคารที่สร้างจริง ${s.buildings.length} หลัง`;
  label.append(strong,small);
  stage.querySelectorAll('.he-pin').forEach(el=>el.remove());
  if(phase===7){pins.forEach(pin=>{const b=document.createElement('button');b.className='he-pin';b.type='button';b.style.left=pin.x+'%';b.style.top=pin.y+'%';b.textContent=pin.name;b.title='ดูสถานะและไปยังเมนูก่อสร้าง '+pin.name;b.addEventListener('click',()=>pinClick(pin));stage.append(b);});}
  else{const type=['ward','ward','villa','homecare','branch','hospital'][i];const pin={x:50,y:65,name:phases[i][0],type};const b=document.createElement('button');b.className='he-pin';b.type='button';b.style.left='50%';b.style.top='65%';b.textContent='ดูอาคาร / ก่อสร้าง';b.addEventListener('click',()=>pinClick(pin));stage.append(b);}
  list.querySelectorAll('[data-phase]').forEach(b=>{const n=Number(b.dataset.phase);b.disabled=n>s.chapter-3;b.setAttribute('aria-pressed',String(n===phase));b.title=b.disabled?`ปลดล็อก V${n+3} ก่อน`:phases[n-1][0];});
 }
 function setMode(m){mode=m;const art=m==='art';stage.hidden=!art;list.hidden=!art;cap.hidden=!art;wrap.hidden=art;
  document.getElementById('he-art-mode').setAttribute('aria-pressed',String(art));document.getElementById('he-sim-mode').setAttribute('aria-pressed',String(!art));
  if(!art){bridge.render?.();}
 }
 document.getElementById('he-art-mode').addEventListener('click',()=>setMode('art'));
 document.getElementById('he-sim-mode').addEventListener('click',()=>setMode('sim'));
 // Decorate live build buttons with concept art. Observer survives core render's replaceChildren/innerHTML.
 const builds=document.getElementById('buildings');
 function updateThumbs(){if(!builds)return;for(const b of builds.querySelectorAll('[data-building]')){
  if(b.querySelector('.he-building-thumb'))continue;const id=thumbMap[b.dataset.building];if(!id)continue;
  const im=document.createElement('img');im.className='he-building-thumb';im.src=`assets/building-${id}.webp`;im.alt='ภาพอ้างอิง '+b.dataset.building;im.loading='lazy';b.prepend(im);
 }}
 if(builds){new MutationObserver(()=>{if(!builds.querySelector('.he-building-thumb'))updateThumbs();}).observe(builds,{childList:true});updateThumbs();}
 window.addEventListener('healthcare:changed',()=>drawStage());
 setMode(window.matchMedia('(max-width:760px)').matches?'sim':'art');drawStage();
 window.HealthcareVisual={version:'10.3',getMode:()=>mode,getPhase:()=>phase,setMode,setPhase(n){if(n>=1&&n<=7){phase=n;drawStage();}}};
})();
