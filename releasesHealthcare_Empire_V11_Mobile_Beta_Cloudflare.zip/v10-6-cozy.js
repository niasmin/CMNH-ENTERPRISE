/* Healthcare Empire V10.6: mobile-friendly original cozy village skin. Gameplay uses V10.5 bridge. */
(()=>{'use strict';
const B=window.HealthcareBridge,V=window.HealthcareVisual,M=window.HealthcareMobile,G=window.HealthcareCore;
if(!B||!G||!M)return;
const $=id=>document.getElementById(id),asset=n=>'assets/'+n;
const stage=document.createElement('section');stage.className='he-cozy';stage.setAttribute('aria-label','หมู่บ้านศูนย์ดูแลผู้สูงอายุ');
stage.innerHTML='<div class="he-cozy-world" id="he-cozy-world"><div class="he-cozy-scene" id="he-cozy-scene"></div></div><div class="he-cozy-map-head"><span class="he-cozy-chip" id="he-cozy-day">🌞 Day 1</span><div class="he-cozy-map-btns"><button type="button" id="he-cozy-zoomout" aria-label="ย่อแผนที่">−</button><button type="button" id="he-cozy-zoomin" aria-label="ขยายแผนที่">+</button></div></div><div class="he-cozy-bottom"><button type="button" id="he-cozy-sim">🗺️ แผนที่จำลอง</button><button type="button" id="he-cozy-tour">❔ วิธีเล่น</button></div>';
const help=document.createElement('p');help.className='he-cozy-help';help.textContent='👆 แตะอาคารเพื่อดูรายละเอียด • ลากแผนที่เพื่อสำรวจ • กด “สร้าง” เพื่อขยายกิจการ';
const guide=$('he-play-guide'),after=$('he-mob-hud')||document.querySelector('.top');if(guide){guide.after(stage,help);}else{after.after(stage,help);}
const world=$('he-cozy-world'),scene=$('he-cozy-scene');
let scale=.76,px=0,py=0,moving=false,started=null;
function paint(){scene.style.transform=`translate(calc(-50% + ${px}px),calc(-50% + ${py}px)) scale(${scale})`;}
function zoom(v){scale=Math.max(.55,Math.min(1.6,scale*v));paint();}
$('he-cozy-zoomout').onclick=()=>zoom(1/1.2);$('he-cozy-zoomin').onclick=()=>zoom(1.2);
world.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;started={x:e.clientX,y:e.clientY,px,py,id:e.pointerId};moving=false;world.setPointerCapture(e.pointerId);});
world.addEventListener('pointermove',e=>{if(!started||started.id!==e.pointerId)return;const dx=e.clientX-started.x,dy=e.clientY-started.y;if(Math.hypot(dx,dy)>9)moving=true;if(moving){px=Math.max(-290,Math.min(290,started.px+dx));py=Math.max(-250,Math.min(250,started.py+dy));paint();}});
world.addEventListener('pointerup',e=>{if(started?.id===e.pointerId){started=null;setTimeout(()=>moving=false,100);}});world.addEventListener('pointercancel',()=>{started=null;moving=false;});
let pinchDist=null;world.addEventListener('touchmove',e=>{if(e.touches.length===2){const [a,b]=e.touches,d=Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY);if(pinchDist)zoom(d/Math.max(1,pinchDist));pinchDist=d;e.preventDefault();}},{passive:false});world.addEventListener('touchend',()=>pinchDist=null);
const pop=document.createElement('div');pop.className='he-cozy-popup';pop.hidden=true;pop.innerHTML='<header><span id="he-cozy-pop-title">อาคาร</span><button id="he-cozy-pop-close" aria-label="ปิด">×</button></header><div class="he-cozy-popup-body" id="he-cozy-pop-body"></div>';
const scrim=document.createElement('div');scrim.className='he-cozy-scrim';scrim.hidden=true;document.body.append(scrim,pop);
function close(){pop.hidden=true;scrim.hidden=true;}scrim.onclick=close;$('he-cozy-pop-close').onclick=close;
function open(title,markup,buttons=[]){$('he-cozy-pop-title').textContent=title;$('he-cozy-pop-body').innerHTML=markup;const row=document.createElement('div');row.className='he-cozy-actions';for(const [label,fn] of buttons){const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=()=>{close();fn();};row.append(b);}if(buttons.length)$('he-cozy-pop-body').append(row);pop.hidden=false;scrim.hidden=false;}
const names={ward:['🏥 CMNH','building-ward-clean.png'],villa:['🌷 Tranquila','building-villa-clean.png'],lab:['🧴 CM.Derma+','building-lab-clean.png'],homecare:['🚐 Home Care','building-homecare-clean.png'],hospital:['🏥 Neuro Hospital','building-hospital-clean.png'],branch:['🏢 PHC','building-branch-clean.png']};
const positions=[[158,185],[415,185],[280,365],[510,380],[98,465],[400,555],[275,95],[505,85],[75,80],[255,560],[520,580]];
function pick(type){if(names[type])return names[type];if(/villa|vip|premium/.test(type))return names.villa;if(/hospital|neuro/.test(type))return names.hospital;if(/home|care/.test(type))return names.homecare;if(/lab|clinic|derma/.test(type))return names.lab;return names.ward;}
const decor=[['ห้องพักผู้สูงอายุ','room-standard.webp'],['ห้อง VIP','room-vip.webp'],['ห้องกายภาพบำบัด','room-therapy.webp'],['ห้องอาหาร','room-dining.webp'],['ห้องกิจกรรม','room-activity.webp'],['สถานีพยาบาล','room-nurse-station.webp']];
function showRooms(buildingId){if(window.HealthcareRooms){window.HealthcareRooms.open(buildingId);return;}open('🛋️ สำรวจห้องภายใน',`<p>ตัวอย่างห้องของศูนย์ดูแล (ภาพอ้างอิง ไม่ใช่ระบบตกแต่งที่บันทึกได้)</p><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">${decor.map(([n,img])=>`<div style="background:white;border-radius:12px;overflow:hidden"><img src="${asset(img)}" alt="${n}" style="width:100%;height:105px;object-fit:cover"><div style="padding:5px;font-size:11px;color:#557c65;font-weight:700">${n}</div></div>`).join('')}</div>`,[['กลับแผนที่',()=>{}],['ก่อสร้าง',()=>M.open('build')]]);}
function details(building){const [name,img]=pick(building.type);open(name+' #'+building.id,`<img src="${asset(img)}" alt="${name}"><p>อาคารหมายเลข ${building.id} • แตะเข้าอาคารเพื่อดูห้องและกิจกรรมของอาคารหลังนี้โดยเฉพาะ</p>`,[['🏠 เข้าอาคาร / ตกแต่ง',()=>showRooms(building.id)],['🔨 ก่อสร้าง',()=>M.open('build')]]);}
function draw(){const s=B.getState();if(!s)return;$('he-cozy-day').textContent=`🌤️ วันที่ ${s.day} · ${String(s.hour).padStart(2,'0')}:00`;
 scene.innerHTML='<div class="he-cozy-path"></div><div class="he-cozy-pond"></div>'+[[20,90],[540,105],[45,580],[520,590],[310,70],[320,595]].map(([x,y])=>`<div class="he-cozy-tree" style="left:${x}px;top:${y}px">🌳</div>`).join('');
 const buildings=s.buildings.slice(0,11);
 if(!buildings.length){const empty=document.createElement('button');empty.type='button';empty.className='he-cozy-empty';empty.textContent='＋ สร้างอาคารหลังแรก';empty.onclick=()=>M.open('build');scene.append(empty);}
 buildings.forEach((building,i)=>{const [name,img]=pick(building.type),[x,y]=positions[i];const el=document.createElement('button');el.type='button';el.className='he-cozy-house';el.style.left=x+'px';el.style.top=y+'px';el.style.zIndex=String(10+Math.floor(y));el.innerHTML=`<img src="${asset(img)}" alt=""><span class="he-cozy-count">#${building.id}</span><b>${name}</b>`;el.onclick=()=>{if(!moving)details(building);};scene.append(el);});
 const avatars=['avatar-nurse_blue_01.png','avatar-care_staff_01.png','avatar-resident_man.png','avatar-therapist.png'];const people=Math.min(4,Math.max(1,(s.staff?.caregiver||0)+(s.staff?.rn||0)));
 for(let i=0;i<people;i++){const a=document.createElement('div');a.className='he-cozy-avatar';a.style.left=(90+i*112)+'px';a.style.top=(380+i%2*105)+'px';a.style.zIndex='90';a.innerHTML=`<img src="${asset(avatars[i])}" alt="">`;scene.append(a);}
}
$('he-cozy-sim').onclick=()=>{document.body.classList.toggle('he-cozy-show-old');V?.setMode('sim');$('he-cozy-sim').textContent=document.body.classList.contains('he-cozy-show-old')?'🌷 กลับแผนที่การ์ตูน':'🗺️ แผนที่จำลอง';if(document.body.classList.contains('he-cozy-show-old'))$('he-section-map')?.scrollIntoView({behavior:'smooth'});};
const roomsBtn=document.createElement('button');roomsBtn.type='button';roomsBtn.textContent='🏠 เข้าอาคาร';roomsBtn.id='he-cozy-enter';document.querySelector('.he-cozy-bottom')?.prepend(roomsBtn);roomsBtn.onclick=()=>window.HealthcareRooms?.open();
$('he-cozy-tour').onclick=()=>{window.HealthcarePlayGuide?.open();$('he-play-guide')?.scrollIntoView({behavior:'smooth'});};
const nav=document.querySelector('.he-mob-nav');if(nav)nav.querySelector('[data-tab="map"]')?.addEventListener('click',()=>{document.body.classList.remove('he-cozy-show-old');$('he-cozy-sim').textContent='🗺️ แผนที่จำลอง';stage.scrollIntoView({behavior:'smooth'});});
window.addEventListener('healthcare:changed',draw);window.addEventListener('healthcare:action',()=>setTimeout(draw,10));draw();paint();
window.HealthcareCozy={version:'10.8',refresh:draw,showRooms};
})();
