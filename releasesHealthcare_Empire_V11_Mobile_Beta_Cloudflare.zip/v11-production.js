/* V11 mobile beta: gameplay tutorial wired to real engine commands, no mock completion. */
(()=>{'use strict';
const bridge=window.HealthcareBridge,core=window.HealthcareCore;
if(!bridge||!core)return;
const q=s=>document.querySelector(s);
const box=document.createElement('div');box.className='he-v11-task';box.id='he-v11-task';box.innerHTML='<div>⭐ <strong id="he-v11-task-title">ภารกิจแรก</strong><div id="he-v11-task-sub">สร้างห้องพักผู้สูงอายุ</div></div><button id="he-v11-task-go" type="button">ไปเลย ›</button>';
const welcome=document.createElement('div');welcome.className='he-v11-welcome';welcome.id='he-v11-welcome';welcome.hidden=true;
welcome.innerHTML='<div class="he-v11-card" role="dialog" aria-modal="true" aria-label="เริ่มเกม"><div style="font-size:52px">🏥🌷</div><h2>Healthcare Empire</h2><p>สร้างศูนย์ดูแลผู้สูงอายุของคุณเอง เริ่มจากสร้างอาคาร จ้างผู้ดูแล รับผู้พักอาศัย แล้วเดินเวลาเพื่อบริหารรายรับรายจ่าย</p><button id="he-v11-start" type="button">▶ เริ่มเล่นเกม</button></div>';
document.body.append(box,welcome);
const get=()=>bridge.getState();
let base=null;try{base=JSON.parse(sessionStorage.getItem('he-v11-base')||'null');}catch{}
if(!base){const s=get();base={buildings:s.buildings.length,staff:Object.values(s.staff||{}).reduce((a,b)=>a+b,0),residents:s.residents,day:s.day};try{sessionStorage.setItem('he-v11-base',JSON.stringify(base));}catch{}}
const staff=s=>Object.values(s.staff||{}).reduce((a,b)=>a+b,0);
function phase(){const s=get();if(s.buildings.length<=base.buildings)return 0;if(staff(s)<=base.staff)return 1;if(s.residents<=base.residents)return 2;if(s.day<=base.day)return 3;return 4;}
const steps=[['สร้างอาคารเพิ่ม 1 หลัง','เปิดเมนูสร้าง แล้วเลือกอาคารที่ปลดล็อก','build'],['จ้างบุคลากร 1 คน','เปิดเมนูบุคลากร แล้วกดจ้าง','team'],['รับผู้พักอาศัย 1 คน','เปิดเมนูบุคลากร แล้วกดรับเข้าศูนย์','team'],['เดินเวลา 1 วัน','กด +1 วัน เพื่อคำนวณรายรับรายจ่าย','time'],['เริ่มบริหารได้แล้ว!','แตะอาคารเพื่อดูห้องภายใน','rooms']];
function render(){const p=phase(),x=steps[p];document.getElementById('he-v11-task-title').textContent=(p===4?'🎉 ':'ภารกิจ '+(p+1)+'/4 · ')+x[0];document.getElementById('he-v11-task-sub').textContent=x[1];document.getElementById('he-v11-task-go').textContent=p===4?'เข้าอาคาร ›':'ไปเลย ›';}
function act(){const p=phase(),tab=steps[p][2];if(tab==='time'){q('[data-tick="24"]')?.click();return;}if(tab==='rooms'){window.HealthcareRooms?.open();return;}window.HealthcareMobile?.open(tab);}
document.getElementById('he-v11-task-go').addEventListener('click',act);
document.getElementById('he-v11-start').addEventListener('click',()=>{welcome.hidden=true;try{localStorage.setItem('he-v11-onboarded','1');}catch{}act();});
let seen=false;try{seen=localStorage.getItem('he-v11-onboarded')==='1';}catch{}
if(!seen&&matchMedia('(max-width:760px)').matches)welcome.hidden=false;
window.addEventListener('healthcare:changed',render);render();
window.HealthcareV11={version:'11.0-beta',phase,openGuide:()=>{welcome.hidden=false;}};
})();