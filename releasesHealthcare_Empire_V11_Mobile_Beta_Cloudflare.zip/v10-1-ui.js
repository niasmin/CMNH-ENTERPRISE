/* Healthcare Empire V10.1 • Progressive UX enhancement.
 * Uses the existing HealthcareBridge and DOM; never changes economy, saves or auth tokens.
 */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const bridge = window.HealthcareBridge;
  if (!bridge || !$('scene') || !document.querySelector('.shell')) return;
  const stats = document.querySelector('.stats');
  const mapPanel = $('scene').closest('.panel');
  const growthPanel = $('chapters')?.closest('.panel');
  const financePanel = $('finance')?.closest('.panel');
  const operationsPanel = $('buildings')?.closest('.panel');
  const carePanel = $('care-actions')?.closest('.panel');
  const logPanel = $('log')?.closest('.panel');
  const tourKey = 'he-v10-1-tour-complete';
  const safeStorage = {
    get(k) { try { return localStorage.getItem(k); } catch { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch {} },
  };
  const sections = [
    { id:'map', label:'แผนที่', icon:'🗺️', target:mapPanel },
    { id:'operations', label:'บริหาร', icon:'🏗️', target:operationsPanel },
    { id:'care', label:'ดูแล', icon:'💚', target:carePanel },
    { id:'growth', label:'เติบโต', icon:'📈', target:growthPanel },
    { id:'account', label:'บัญชี', icon:'☁️', target:$('account-open') },
  ];
  sections.forEach(s => { if (s.target && s.id !== 'account') s.target.id = 'he-section-' + s.id; });
  if (financePanel) financePanel.id = 'he-section-finance';
  if (logPanel) logPanel.id = 'he-section-events';

  // Welcome + save status strip (keeps Cloud Save implementation separate).
  const quickbar = document.createElement('section');
  quickbar.className = 'he-quickbar';
  quickbar.setAttribute('aria-label', 'คำแนะนำและสถานะเกม');
  quickbar.innerHTML = `<div class="he-summary"><span class="he-summary-icon" aria-hidden="true">🌿</span><div><strong id="he-guidance-title">ศูนย์ดูแลของคุณกำลังเติบโต</strong><small id="he-guidance-subtitle">ดูภารกิจแนะนำเพื่อเริ่มเล่น</small></div></div><div class="he-quickbar-actions"><button type="button" class="he-mini-btn" id="he-tour-open">❔ สอนเล่น</button><button type="button" class="he-mini-btn he-accent" id="he-quick-save">💾 บันทึก</button></div><span class="he-save-note" id="he-save-note" role="status" aria-live="polite">● บันทึกในเครื่อง</span>`;
  stats?.before(quickbar);
  $('he-quick-save').addEventListener('click', () => $('save')?.click());

  // Five-action navigation. Buttons only navigate existing UI, not change game state.
  const nav = document.createElement('nav');
  nav.className = 'he-bottom-nav';
  nav.setAttribute('aria-label', 'เมนูเกมหลัก');
  for (const s of sections) {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.heNav = s.id;
    button.setAttribute('aria-label', s.label);
    button.innerHTML = `<span aria-hidden="true">${s.icon}</span>${s.label}`;
    button.addEventListener('click', () => {
      if (s.id === 'account') $('account-open')?.click();
      else s.target?.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block:'start' });
      nav.querySelectorAll('button').forEach(b => b.removeAttribute('aria-current'));
      button.setAttribute('aria-current', 'true');
    });
    nav.appendChild(button);
  }
  nav.firstElementChild?.setAttribute('aria-current', 'true');
  document.body.appendChild(nav);

  // Non-intrusive early-game goals, derived from existing simulation state.
  const goals = document.createElement('div');
  goals.id = 'he-goals';
  goals.className = 'panel';
  goals.setAttribute('aria-label', 'เป้าหมายเริ่มต้น');
  goals.innerHTML = `<div class="row"><h2>🎯 ภารกิจแนะนำ</h2><span class="tag" id="he-goal-count">0/4</span></div><p class="hint">ทำตามลำดับเพื่อเรียนรู้ระบบบริหารศูนย์</p><div class="he-progress-track"><span id="he-goal-bar" style="width:0%"></span></div><div id="he-goal-list"></div><p class="he-feedback" id="he-goal-tip"></p>`;
  carePanel?.parentElement?.insertBefore(goals, carePanel);
  const goalDefs = [
    { label:'เริ่มบริหารศูนย์', tip:'ดูแผนที่และข้อมูลศูนย์', test:s=>s.day>=1 },
    { label:'มีผู้พักอาศัยอย่างน้อย 9 คน', tip:'กดรับเข้าศูนย์ในเมนูบริหาร', test:s=>s.residents>=9 },
    { label:'สร้างอาคารอย่างน้อย 4 หลัง', tip:'เพิ่มหอพักหรือสวนในเมนูก่อสร้าง', test:s=>s.buildings.length>=4 },
    { label:'พัฒนาศูนย์ถึง V5', tip:'ตรวจเงินสดและชื่อเสียงก่อนปลดล็อก', test:s=>s.chapter>=5 },
  ];
  function updateGoals() {
    let s;
    try { s = bridge.getState(); } catch { return; }
    const done = goalDefs.filter(g => g.test(s)).length;
    $('he-goal-count').textContent = `${done}/${goalDefs.length}`;
    $('he-goal-bar').style.width = `${100*done/goalDefs.length}%`;
    $('he-goal-list').replaceChildren(...goalDefs.map(g => {
      const row = document.createElement('div');
      const passed = !!g.test(s);
      row.className = 'he-goal' + (passed ? ' done' : '');
      const mark = document.createElement('span'); mark.className='he-goal-mark';mark.textContent=passed?'✓':'○';
      const copy = document.createElement('div');
      const strong=document.createElement('strong');strong.textContent=g.label;
      const small=document.createElement('small');small.textContent=g.tip;
      copy.append(strong,small);row.append(mark,copy);return row;
    }));
    const next = goalDefs.find(g=>!g.test(s));
    $('he-goal-tip').textContent = next ? `แนะนำขั้นถัดไป: ${next.label}` : 'เยี่ยมมาก! คุณเรียนรู้พื้นฐานครบแล้ว ลองขยายกิจการต่อได้เลย';
    $('he-guidance-title').textContent = s.chapter>=10 ? 'Healthcare Empire • V10' : `ศูนย์ของคุณ • V${s.chapter}.0`;
    $('he-guidance-subtitle').textContent = next ? next.label : 'ขยายอาณาจักร Healthcare ต่อได้เลย';
  }
  updateGoals();
  // Render is invoked by the game after every successful command, which updates these nodes.
  // MutationObserver avoids polling and does not hook or replace game logic.
  const watchNode = $('cash');
  if (watchNode) new MutationObserver(updateGoals).observe(watchNode,{childList:true,characterData:true,subtree:true});

  // Tour is opt-in and does not modify game state.
  const steps = [
    { icon:'🏥', title:'ยินดีต้อนรับสู่ Healthcare Empire', body:'คุณเป็นผู้บริหารศูนย์ดูแลผู้สูงอายุ เริ่มจากดูสถานะการเงิน จำนวนผู้พักอาศัย และคุณภาพชีวิตบนหน้าจอหลัก' },
    { icon:'🗺️', title:'รู้จักแผนที่ศูนย์', body:'อาคารและบุคลากรปรากฏบนแผนที่ไอโซเมตริก แตะอาคารเพื่อดูรายละเอียด และใช้ปุ่ม +1 ชม. เพื่อเดินเวลา' },
    { icon:'🏗️', title:'สร้างอาคารและจ้างทีม', body:'เปิดเมนูบริหารเพื่อเพิ่มหอพัก สวน หรือจ้าง RN, PN, Caregiver, PT และ OT อย่าลืมดูเงินสดและค่าใช้จ่าย' },
    { icon:'💚', title:'ดูแลผู้พักอาศัย', body:'รับผู้พักอาศัยเมื่อมีเตียงว่างและบุคลากรเพียงพอ เมื่อปลดล็อก V5 จะเริ่มใช้กิจกรรมดูแลและฟื้นฟูได้' },
    { icon:'☁️', title:'บันทึกและเติบโตต่อ', body:'เกมบันทึกในเครื่องได้ และสำรองผ่านปุ่มบันทึก ระบบ Cloud Save ใช้ได้เมื่อเชื่อม Supabase และ Cloudflare Worker สำเร็จแล้ว' },
  ];
  const tour = document.createElement('div');
  tour.id='he-onboarding';tour.className='he-onboarding';
  tour.setAttribute('role','dialog');tour.setAttribute('aria-modal','true');tour.setAttribute('aria-labelledby','he-tour-title');
  tour.innerHTML=`<div class="he-tour-card"><div class="he-tour-top"><span class="he-tour-kicker">QUICK START • 5 STEPS</span><button type="button" class="he-tour-close" id="he-tour-close">ข้าม / ปิด</button></div><div class="he-tour-art" id="he-tour-art" aria-hidden="true">🏥</div><h2 id="he-tour-title"></h2><p id="he-tour-body"></p><div class="he-tour-progress" id="he-tour-progress" aria-label="ความคืบหน้าการสอนเล่น"></div><div class="he-tour-controls"><button type="button" id="he-tour-prev">ย้อนกลับ</button><button type="button" class="he-primary" id="he-tour-next">ถัดไป →</button></div><div class="he-tour-tip">สอนเล่นนี้ไม่มีการหักเงินหรือแก้ไขข้อมูลเกม</div></div>`;
  document.body.appendChild(tour);
  let stepIndex=0,previousFocus=null;
  function drawTour(){
    const step=steps[stepIndex];
    $('he-tour-art').textContent=step.icon;$('he-tour-title').textContent=step.title;$('he-tour-body').textContent=step.body;
    $('he-tour-prev').disabled=stepIndex===0;
    $('he-tour-next').textContent=stepIndex===steps.length-1?'เริ่มเล่นเลย ✓':'ถัดไป →';
    $('he-tour-progress').replaceChildren(...steps.map((_,i)=>{const p=document.createElement('i');if(i<=stepIndex)p.className='active';return p;}));
  }
  function openTour(){previousFocus=document.activeElement;stepIndex=0;drawTour();tour.classList.add('he-open');$('he-tour-close').focus();}
  function closeTour(){tour.classList.remove('he-open');safeStorage.set(tourKey,'1');previousFocus?.focus?.();}
  $('he-tour-open').addEventListener('click',openTour);
  $('he-tour-close').addEventListener('click',closeTour);
  $('he-tour-prev').addEventListener('click',()=>{stepIndex=Math.max(0,stepIndex-1);drawTour();});
  $('he-tour-next').addEventListener('click',()=>{if(stepIndex===steps.length-1)closeTour();else{stepIndex++;drawTour();}});
  tour.addEventListener('click',e=>{if(e.target===tour)closeTour();});
  tour.addEventListener('keydown',e=>{
    if(e.key==='Escape'){e.preventDefault();closeTour();}
    if(e.key==='Tab'){
      const focusable=[...tour.querySelectorAll('button:not([disabled])')];
      const first=focusable[0],last=focusable[focusable.length-1];
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
    }
  });
  document.addEventListener('keydown',e=>{
    if(e.key==='?'&&!e.altKey&&!e.ctrlKey&&!e.metaKey&&!(e.target instanceof HTMLInputElement)&&!(e.target instanceof HTMLTextAreaElement)){e.preventDefault();openTour();}
  });
  // A visible local/cloud indicator. Auth module updates #he-auth-status itself.
  const statusNode=$('he-auth-status');
  const refreshSaveNote=()=>{$('he-save-note').textContent=statusNode?.textContent||'● บันทึกในเครื่อง';};
  refreshSaveNote();
  if(statusNode)new MutationObserver(refreshSaveNote).observe(statusNode,{childList:true,subtree:true,characterData:true});
  // Expose small read-only UX testing interface.
  window.HealthcareUX = Object.freeze({openTutorial:openTour,closeTutorial:closeTour,updateGoals});
  // First visit: show a nonblocking prompt via quickbar, not a forced modal.
  if(!safeStorage.get(tourKey))$('he-tour-open').textContent='✨ เริ่มสอนเล่น';
})();
