/* PUBLIC client configuration ONLY. Do not add a service_role key or database credentials. */
window.HE_CLOUD_CONFIG = {
  supabaseUrl: 'https://REPLACE_PROJECT_REF.supabase.co',
  supabasePublishableKey: 'REPLACE_WITH_SUPABASE_PUBLISHABLE_KEY',
  workerApiUrl: 'https://REPLACE_WORKER_NAME.REPLACE_SUBDOMAIN.workers.dev',
};
