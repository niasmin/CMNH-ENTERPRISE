/* Healthcare Empire Auth + Cloud Save. All passwords go directly to Supabase Auth.
 * All saves go to the Worker, which verifies the Supabase JWT and enforces user isolation.
 */
(() => {
  'use strict';
  const config = window.HE_CLOUD_CONFIG || {};
  const bridge = window.HealthcareBridge;
  if (!bridge) { console.error('HealthcareBridge is missing'); return; }
  const KEY = 'he-supabase-session-v1';
  const configured = /^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(config.supabaseUrl || '') &&
    typeof config.supabasePublishableKey === 'string' && !config.supabasePublishableKey.startsWith('REPLACE_') &&
    /^https:\/\//.test(config.workerApiUrl || '') && !config.workerApiUrl.includes('REPLACE_');
  let session = null, revision = 0, paused = true, busy = false, dirty = false, timer = null, refreshPromise = null;
  let loginEpoch = 0;
  try { const stored = JSON.parse(localStorage.getItem(KEY) || 'null'); if (stored?.access_token && stored?.refresh_token && stored?.user?.id) session = stored; } catch {}

  const style = document.createElement('style');
  style.textContent = `
  #he-auth-overlay{position:fixed;inset:0;z-index:5000;display:none;align-items:center;justify-content:center;padding:16px;background:#091e1bc7;overflow-y:auto}
  #he-auth-overlay.he-open{display:flex}#he-auth-dialog{width:min(460px,100%);max-height:92vh;overflow:auto;background:#f7faf7;color:#143d38;border-radius:18px;box-shadow:0 25px 75px #0007;padding:22px;font:15px system-ui,sans-serif}
  #he-auth-dialog h2{margin:0 0 8px;font-size:22px}#he-auth-dialog p{line-height:1.5;color:#486b63}#he-auth-dialog label{display:block;font-weight:600;margin:12px 0 4px}
  #he-auth-dialog input{width:100%;padding:12px;border:1px solid #acc6bf;border-radius:10px;font:inherit;box-sizing:border-box;background:#fff;color:#123d36}
  #he-auth-dialog button{padding:11px 14px;border:0;border-radius:10px;background:#207969;color:#fff;font:600 14px system-ui;cursor:pointer}
  #he-auth-dialog button.he-secondary{background:#e3eee9;color:#164a41}#he-auth-dialog button:disabled{opacity:.5;cursor:wait}
  #he-auth-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}#he-auth-actions button{flex:1;min-width:120px}
  #he-auth-message{min-height:24px;margin:12px 0;color:#235c53;font-size:13px;white-space:pre-wrap}
  #he-auth-status{font-size:12px;display:inline-block;padding:4px 9px;border-radius:99px;background:#d7e8e1;color:#21544b;margin-left:6px}
  #he-auth-dialog small{color:#657e76}#he-auth-close{float:right;background:#e3eee9!important;color:#164a41!important}
  `;
  document.head.appendChild(style);
  const overlay = document.createElement('div'); overlay.id = 'he-auth-overlay'; overlay.setAttribute('role','dialog'); overlay.setAttribute('aria-modal','true'); overlay.setAttribute('aria-label','บัญชีผู้เล่นและ Cloud Save');
  overlay.innerHTML = `<div id="he-auth-dialog"><button id="he-auth-close" type="button" aria-label="ปิด">✕</button><h2>☁️ บัญชีผู้เล่น</h2><div id="he-auth-view"></div><div id="he-auth-message" role="status" aria-live="polite"></div><div id="he-auth-actions"></div><small>เกมบันทึกในเครื่องได้เสมอ • Cloud Save ใช้ได้เมื่อเชื่อมต่อระบบแล้ว</small></div>`;
  document.body.appendChild(overlay);
  const view = document.getElementById('he-auth-view'), actions = document.getElementById('he-auth-actions'), msg = document.getElementById('he-auth-message');
  const status = document.createElement('span'); status.id='he-auth-status'; status.textContent='บันทึกในเครื่อง';
  document.getElementById('account-open')?.after(status);
  const say = text => { msg.textContent = text; };
  const setStatus = text => { status.textContent = text; };
  const close = () => overlay.classList.remove('he-open');
  const open = () => { overlay.classList.add('he-open'); renderAccount(); };
  document.getElementById('account-open')?.addEventListener('click', open);
  document.getElementById('he-auth-close').addEventListener('click', close);
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
  function button(label, fn, secondary = false) {
    const el = document.createElement('button'); el.type = 'button'; el.textContent = label;
    if (secondary) el.className = 'he-secondary';
    el.addEventListener('click', async () => { el.disabled = true; try { await fn(); } catch (e) { say(e.message || 'เกิดข้อผิดพลาด'); } finally { el.disabled = false; } });
    actions.appendChild(el); return el;
  }
  function setSession(next) {
    session = next;
    if (next) localStorage.setItem(KEY, JSON.stringify(next)); else localStorage.removeItem(KEY);
  }
  async function authRequest(path, data, token) {
    const url = config.supabaseUrl.replace(/\/$/, '') + '/auth/v1/' + path;
    const headers = { apikey: config.supabasePublishableKey, 'Content-Type': 'application/json' };
    if (token) headers.Authorization = 'Bearer ' + token;
    const response = await fetch(url, { method: 'POST', headers, body: JSON.stringify(data) });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw Error(body.msg || body.error_description || body.message || 'ไม่สามารถยืนยันตัวตนได้');
    return body;
  }
  async function refreshSession() {
    if (!session?.refresh_token) throw Error('กรุณาเข้าสู่ระบบใหม่');
    if (!refreshPromise) refreshPromise = (async () => {
      const result = await authRequest('token?grant_type=refresh_token', { refresh_token: session.refresh_token });
      if (!result.access_token || !result.refresh_token) throw Error('ไม่สามารถต่ออายุเซสชัน');
      setSession(result); return result;
    })().finally(() => { refreshPromise = null; });
    return refreshPromise;
  }
  async function accessToken() {
    if (!session) throw Error('กรุณาเข้าสู่ระบบก่อน');
    if (!session.expires_at || Date.now()/1000 > session.expires_at - 90) await refreshSession();
    return session.access_token;
  }
  async function api(method, payload, match, retry = true) {
    const token = await accessToken();
    const headers = { Authorization: 'Bearer ' + token };
    if (payload !== undefined) headers['Content-Type'] = 'application/json';
    if (match !== undefined) headers['If-Match'] = String(match);
    const response = await fetch(config.workerApiUrl.replace(/\/$/, '') + '/api/save/main', {
      method, headers, body: payload === undefined ? undefined : JSON.stringify(payload),
    });
    if (response.status === 401 && retry) { await refreshSession(); return api(method, payload, match, false); }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) { const e = Error(data.error || 'Cloud Save ไม่สำเร็จ'); e.status = response.status; throw e; }
    return data;
  }
  function choose(title, description, options) {
    open(); view.replaceChildren(); actions.replaceChildren(); say('');
    const h = document.createElement('h3'); h.textContent = title; view.appendChild(h);
    const p = document.createElement('p'); p.textContent = description; view.appendChild(p);
    for (const opt of options) button(opt.label, opt.action, !!opt.secondary);
  }
  async function loadCloud() {
    const cloud = await api('GET');
    if (!window.HealthcareCore.validate(cloud.game)) throw Error('Cloud Save ไม่ตรงกับเวอร์ชันเกมนี้');
    bridge.loadState(cloud.game); revision = cloud.revision; paused = false; dirty = false;
    setStatus('☁️ โหลดจาก Cloud แล้ว'); close(); return cloud;
  }
  async function saveCloud() {
    if (!session || paused || busy) { dirty = true; return; }
    busy = true; dirty = false;
    const userId = session.user.id;
    const snapshot = bridge.getState();
    try {
      const result = await api('PUT', { game: snapshot }, revision);
      if (!session || session.user.id !== userId) return;
      revision = result.revision; setStatus('☁️ บันทึกแล้ว');
      if (JSON.stringify(snapshot) !== JSON.stringify(bridge.getState())) dirty = true;
    } catch (e) {
      dirty = true;
      if (e.status === 409) {
        paused = true; setStatus('⚠️ Save ขัดแย้ง');
        choose('พบข้อมูล Cloud ที่เปลี่ยนไป', 'ข้อมูลบน Cloud ถูกแก้ไขจากอุปกรณ์อื่น ระบบจะไม่เขียนทับอัตโนมัติ', [
          { label: 'ใช้ข้อมูลบน Cloud', action: async () => { await loadCloud(); } },
          { label: 'ใช้ข้อมูลเครื่องนี้แทน', action: async () => {
            if (!window.confirm('ยืนยันใช้ข้อมูลในเครื่องนี้แทนข้อมูล Cloud ล่าสุด?')) return;
            const current = await api('GET'); revision = current.revision; paused = false;
            await saveCloud(); close();
          }, secondary: true },
        ]);
      } else { paused = true; setStatus('⚠️ Cloud ไม่สำเร็จ (ยังเก็บในเครื่อง)'); }
    } finally {
      busy = false;
      if (dirty && !paused && session) scheduleSave();
    }
  }
  function scheduleSave() {
    if (!session || paused) return;
    dirty = true;
    clearTimeout(timer);
    timer = setTimeout(() => { if (!busy) void saveCloud(); }, 1800);
  }
  async function afterLogin(newSession) {
    clearTimeout(timer); loginEpoch++;
    const epoch = loginEpoch;
    setSession(newSession); revision = 0; paused = true; dirty = false;
    bridge.setIdentity(newSession.user.id);
    setStatus('กำลังตรวจสอบ Cloud...');
    let cloud;
    try { cloud = await api('GET'); }
    catch (e) {
      if (e.status !== 404) { setStatus('⚠️ เชื่อม Cloud ไม่ได้'); say('เข้าสู่ระบบแล้ว แต่ยังโหลด Cloud ไม่ได้ ข้อมูลในเครื่องยังปลอดภัย'); return; }
    }
    if (epoch !== loginEpoch) return;
    if (cloud) {
      if (!window.HealthcareCore.validate(cloud.game)) { setStatus('⚠️ Save ไม่รองรับ'); say('Cloud Save ไม่ตรงกับเวอร์ชันเกม โปรดสำรองข้อมูลก่อนดำเนินการ'); return; }
      revision = cloud.revision;
      if (bridge.hasLocalSave() && JSON.stringify(bridge.getState()) !== JSON.stringify(cloud.game)) {
        choose('พบ Save ทั้งในเครื่องและ Cloud', 'เลือกข้อมูลที่ต้องการใช้ ระบบจะไม่เขียนทับโดยไม่ได้รับอนุญาต', [
          { label: 'โหลดจาก Cloud', action: loadCloud },
          { label: 'ใช้ Save ในเครื่องแทน', action: async () => {
            if (!window.confirm('ยืนยันแทนที่ Cloud Save ด้วยข้อมูลในเครื่อง?')) return;
            paused = false; await saveCloud(); close();
          }, secondary: true },
        ]);
      } else { bridge.loadState(cloud.game); paused = false; dirty = false; setStatus('☁️ เชื่อมต่อแล้ว'); close(); }
      return;
    }
    // No Cloud Save. Offer guest migration only after explicit player confirmation.
    const guest = bridge.getGuestState();
    if (!bridge.hasLocalSave() && guest) {
      choose('เริ่มใช้ Cloud Save', 'พบเกมที่เคยเล่นในโหมดผู้เยี่ยมชม ต้องการย้ายความคืบหน้าเข้าบัญชีนี้หรือไม่?', [
        { label: 'นำเข้า Save ผู้เยี่ยมชม', action: async () => { bridge.loadState(guest); paused = false; await saveCloud(); close(); } },
        { label: 'เริ่มเกมใหม่ในบัญชีนี้', action: async () => { paused = false; await saveCloud(); close(); }, secondary: true },
      ]);
    } else {
      paused = false; setStatus('☁️ พร้อมบันทึก');
      if (bridge.hasLocalSave()) await saveCloud();
      close();
    }
  }
  async function login(email, password, isSignUp) {
    say('กำลังติดต่อ Supabase...');
    const body = await authRequest(isSignUp ? 'signup' : 'token?grant_type=password', { email, password });
    if (!body.access_token || !body.user) {
      say('สมัครสมาชิกแล้ว กรุณาตรวจสอบอีเมลและยืนยันบัญชีก่อนเข้าสู่ระบบ'); return;
    }
    await afterLogin(body);
  }
  async function signOut() {
    clearTimeout(timer); loginEpoch++; paused = true; dirty = false;
    // Session revocation is best-effort. Locally discard token even when offline.
    try { if (session) await authRequest('logout', {}, session.access_token); } catch {}
    setSession(null); revision = 0; bridge.setIdentity(null);
    setStatus('บันทึกในเครื่อง'); close();
  }
  function renderAccount(isSignUp = false) {
    view.replaceChildren(); actions.replaceChildren(); say('');
    if (!configured) {
      const p = document.createElement('p'); p.textContent = 'ยังไม่ได้ตั้งค่า Supabase และ Worker API กรุณาแก้ไฟล์ cloud-config.js ตามคู่มือติดตั้ง เกมยังเล่นและบันทึกในเครื่องได้'; view.appendChild(p); setStatus('บันทึกในเครื่อง'); return;
    }
    if (session) {
      const p = document.createElement('p'); p.textContent = 'เข้าสู่ระบบ: ' + (session.user.email || session.user.id); view.appendChild(p);
      const q = document.createElement('p'); q.textContent = 'Cloud Save มีระบบตรวจสอบ revision ป้องกันอุปกรณ์อื่นเขียนทับโดยไม่ตั้งใจ'; view.appendChild(q);
      button('บันทึก Cloud ตอนนี้', async () => { if (paused) { await afterLogin(session); return; } await saveCloud(); say('ตรวจสอบสถานะด้านบน'); });
      button('โหลดจาก Cloud', async () => { if (!window.confirm('โหลด Save จาก Cloud แทนเกมที่เปิดอยู่?')) return; await loadCloud(); }, true);
      button('ออกจากระบบ', signOut, true);
      return;
    }
    const p = document.createElement('p'); p.textContent = isSignUp ? 'สมัครบัญชีใหม่ด้วยอีเมลและรหัสผ่าน' : 'เข้าสู่ระบบเพื่อบันทึกเกมข้ามอุปกรณ์'; view.appendChild(p);
    const form = document.createElement('form'); form.id = 'he-auth-form';
    const labelEmail = document.createElement('label'); labelEmail.textContent = 'อีเมล';
    const email = document.createElement('input'); email.type = 'email'; email.autocomplete = 'email'; email.required = true; email.maxLength = 254;
    const labelPassword = document.createElement('label'); labelPassword.textContent = 'รหัสผ่าน (อย่างน้อย 8 ตัวอักษร)';
    const pass = document.createElement('input'); pass.type = 'password'; pass.autocomplete = isSignUp ? 'new-password' : 'current-password'; pass.required = true; pass.minLength = 8;
    const submit = document.createElement('button'); submit.type = 'submit'; submit.textContent = isSignUp ? 'สมัครสมาชิก' : 'เข้าสู่ระบบ'; submit.style.marginTop='14px';
    form.append(labelEmail, email, labelPassword, pass, submit); view.appendChild(form);
    form.addEventListener('submit', async e => {
      e.preventDefault(); submit.disabled = true;
      try { await login(email.value.trim(), pass.value, isSignUp); }
      catch (err) { say(err.message || 'เข้าสู่ระบบไม่สำเร็จ'); }
      finally { submit.disabled = false; }
    });
    button(isSignUp ? 'มีบัญชีแล้ว? เข้าสู่ระบบ' : 'ยังไม่มีบัญชี? สมัครสมาชิก', () => renderAccount(!isSignUp), true);
  }
  window.addEventListener('healthcare:changed', scheduleSave);
  document.getElementById('save')?.addEventListener('click', () => { if (session && !paused) scheduleSave(); });
  window.addEventListener('online', () => { if (session && paused) void afterLogin(session); else if (dirty) scheduleSave(); });
  // Restore session after refresh; Supabase refresh token is used only over HTTPS.
  if (configured && session) {
    setStatus('กำลังเชื่อม Cloud...');
    (async () => {
      try { await accessToken(); await afterLogin(session); }
      catch { setStatus('⚠️ โปรดเข้าสู่ระบบใหม่'); say('เซสชันหมดอายุหรือเชื่อมต่อไม่ได้ โปรดตรวจสอบการเชื่อมต่อ'); }
    })();
  }
  window.HECloud = { open, getStatus: () => ({ signedIn: !!session, revision, paused, configured }) };
})();
