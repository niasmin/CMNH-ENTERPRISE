/* Healthcare Empire V10.5 — gameplay-first onboarding, actual game commands only. */
(()=>{'use strict';
const bridge=window.HealthcareBridge,core=window.HealthcareCore,mobile=window.HealthcareMobile,visual=window.HealthcareVisual;
if(!bridge||!core)return;
const $=id=>document.getElementById(id),key='he-v105-guided-progress';
const isMobile=()=>matchMedia('(max-width:760px)').matches;
const guide=document.createElement('section');guide.id='he-play-guide';guide.className='he-play-guide';guide.setAttribute('aria-label','ภารกิจเริ่มต้น');
guide.innerHTML='<div class="he-guide-head"><strong>🎮 เริ่มเล่นจริง — ภารกิจแรก</strong><button id="he-guide-toggle" type="button">ซ่อน</button></div><div id="he-guide-content"><div class="he-guide-steps" id="he-guide-steps"></div><p id="he-guide-message"></p><button type="button" id="he-guide-do">เริ่มภารกิจ</button><small>ทุกขั้นตอนใช้เงินและข้อมูล Save จริง • กดปุ่มแล้วระบบจะทำรายการให้ทันที</small></div>';
const target=document.querySelector('.he-mob-tools')||document.querySelector('.top');target.after(guide);
let step=0,closed=false;try{step=Math.max(0,Math.min(4,Number(localStorage.getItem(key)||0)));}catch{}
const steps=[
 {title:'สร้างหอพักใหม่',desc:'ใช้เงิน 95,000 บาท เพื่อเพิ่มเตียงอีก 6 เตียง',button:'🏗️ สร้างหอพัก 95,000 ฿',cmd:{type:'build',building:'ward'},selector:'[data-building="ward"]'},
 {title:'รับสมัครผู้ดูแล',desc:'เพิ่มเจ้าหน้าที่ 1 คน เพื่อรองรับผู้พักอาศัย',button:'👩‍⚕️ จ้างผู้ดูแล 1 คน',cmd:{type:'hire',role:'caregiver'},selector:'[data-role="caregiver"]'},
 {title:'รับผู้พักอาศัย',desc:'รับผู้สูงอายุเพิ่ม 1 คน เพื่อเพิ่มรายได้จากการดูแล',button:'🛏️ รับผู้พักอาศัย 1 คน',cmd:{type:'admit'},selector:'[data-action="admit"]'},
 {title:'เดินเวลา 1 วัน',desc:'ขยับเวลาเพื่อดูรายรับและค่าใช้จ่ายที่คำนวณจากกิจการจริง',button:'▶ เดินเวลา +1 วัน',cmd:{type:'tick',hours:24},selector:'[data-tick="24"]'},
 {title:'คุณเริ่มเล่นเป็นแล้ว!',desc:'ลองแตะอาคารในแผนที่เพื่อดูข้อมูล หรือขยายกิจการจากเมนูด้านล่าง',button:'🗺️ เปิดแผนที่ก่อสร้าง',cmd:null,selector:null}
];
function save(){try{localStorage.setItem(key,String(step));}catch{}}
function draw(){const data=steps[step];$('he-guide-steps').textContent=`ขั้นที่ ${Math.min(step+1,4)} จาก 4 — ${data.title}`;$('he-guide-message').textContent=data.desc;$('he-guide-do').textContent=data.button;guide.classList.toggle('he-guide-complete',step===4);}
$('he-guide-do').addEventListener('click',()=>{
 if(step===4){visual?.setMode('sim');mobile?.open('map');return;}
 const s=steps[step],button=document.querySelector(s.selector);
 if(!button||button.disabled){$('he-guide-message').textContent='ขั้นตอนนี้ยังทำไม่ได้: ตรวจสอบเงินสดหรือการปลดล็อกในเมนูบริหาร';return;}
 button.click();
});
window.addEventListener('healthcare:action',e=>{
 const {cmd,ok,reason}=e.detail||{};
 if(!ok){$('he-guide-message').textContent=`ทำรายการไม่สำเร็จ: ${reason}`;return;}
 const current=steps[step];if(current?.cmd&&cmd.type===current.cmd.type&&(!current.cmd.building||cmd.building===current.cmd.building)&&(!current.cmd.role||cmd.role===current.cmd.role)&&(!current.cmd.hours||cmd.hours>=current.cmd.hours)){
  step=Math.min(4,step+1);save();draw();
  if(isMobile()){mobile?.close();visual?.setMode('sim');}
 }
});
$('he-guide-toggle').addEventListener('click',()=>{closed=!closed;$('he-guide-content').hidden=closed;$('he-guide-toggle').textContent=closed?'แสดง':'ซ่อน';});
// Make building/staff menus visibly distinct instead of showing every operation in both tabs.
const sheet=$('he-mobile-sheet'),nav=document.querySelector('.he-mob-nav');
if(sheet&&nav)nav.addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b)sheet.dataset.activeTab=b.dataset.tab;});
// Keep the concept art optional; real canvas is the default map on phones.
if(isMobile())visual?.setMode('sim');
// The original 5-page passive tour is not the default; the new tutorial uses actual actions.
try{localStorage.setItem('he-v10-1-tour-complete','1');}catch{}
draw();
window.HealthcarePlayGuide={getStep:()=>step,open:()=>{closed=false;$('he-guide-content').hidden=false;draw();}};
})();