/* Healthcare Empire V10.2 quality layer: explicit backup/restore, offline feedback,
   keyboard and screen-reader improvements. No changes to game economy or cloud API. */
(() => {
 'use strict';
 const $ = id => document.getElementById(id);
 const bridge = window.HealthcareBridge, core = window.HealthcareCore;
 if (!bridge || !core || !$('scene') || $('he-v10-2-quality')) return;
 const toolbar = document.createElement('section');
 toolbar.id='he-v10-2-quality';toolbar.className='he-v10-2-toolbar';
 toolbar.setAttribute('aria-label','สำรองข้อมูลและสถานะการเชื่อมต่อ');
 toolbar.innerHTML=`<div class="he-v10-2-state"><span id="he-network-dot" aria-hidden="true">●</span><span id="he-network-label" role="status" aria-live="polite">กำลังตรวจสอบเครือข่าย</span></div><div class="he-v10-2-buttons"><button type="button" id="he-backup-export">⬇ สำรอง Save</button><button type="button" id="he-backup-import">⬆ นำเข้า Save</button><input id="he-backup-file" type="file" accept="application/json,.json" hidden aria-label="เลือกไฟล์ Save JSON"></div>`;
 const quickbar=document.querySelector('.he-quickbar');
 if(quickbar)quickbar.after(toolbar);else document.querySelector('.stats')?.before(toolbar);
 const status=$('he-network-label');
 function networkStatus(){
   const online=navigator.onLine;
   toolbar.dataset.network=online?'online':'offline';
   status.textContent=online?'ออนไลน์ • Save ในเครื่องพร้อมใช้':'ออฟไลน์ • เล่นต่อได้ ข้อมูล Cloud อาจยังไม่ซิงก์';
 }
 window.addEventListener('online',networkStatus);window.addEventListener('offline',networkStatus);networkStatus();
 const message=document.createElement('div');message.id='he-backup-notice';message.className='he-backup-notice';message.setAttribute('role','status');message.setAttribute('aria-live','polite');toolbar.after(message);
 function say(s){message.textContent=s;}
 const getFileName=()=>{
   const s=bridge.getState(), date=new Date().toISOString().slice(0,10);
   return `healthcare-empire-v${s.chapter}-day${s.day}-${date}.json`;
 };
 function exportSave(){
   try{
     const game=bridge.getState();if(!core.validate(game))throw Error('ข้อมูลเกมไม่ถูกต้อง');
     const payload=JSON.stringify({format:'healthcare-empire-prototype-save',version:1,exportedAt:new Date().toISOString(),game},null,2);
     const url=URL.createObjectURL(new Blob([payload],{type:'application/json;charset=utf-8'}));
     const a=document.createElement('a');a.href=url;a.download=getFileName();document.body.append(a);a.click();a.remove();
     setTimeout(()=>URL.revokeObjectURL(url),1500);
     say('สำรอง Save เป็นไฟล์ JSON แล้ว เก็บไฟล์นี้ไว้ในที่ปลอดภัย');
   }catch(e){say('สำรอง Save ไม่สำเร็จ: '+(e?.message||'ข้อผิดพลาด'));}
 }
 async function importSave(file){
   if(!file)return;
   if(file.size>1024*1024){say('ไฟล์ Save ใหญ่เกิน 1 MB');return;}
   try{
     const text=await file.text();const parsed=JSON.parse(text);
     const game=parsed?.format==='healthcare-empire-prototype-save'?parsed.game:parsed;
     if(!core.validate(game))throw Error('ไฟล์ไม่ใช่ Save ที่รองรับ');
     if(!window.confirm(`ต้องการแทน Save ปัจจุบันด้วยข้อมูลวันที่ ${game.day} (V${game.chapter}) หรือไม่?\nแนะนำให้สำรองข้อมูลเดิมก่อน`)){
       say('ยกเลิกการนำเข้า ไม่มีการเปลี่ยนข้อมูลเกม');return;
     }
     bridge.loadState(game);
     window.dispatchEvent(new Event('healthcare:changed'));
     window.HealthcareUX?.updateGoals?.();
     say(`นำเข้า Save สำเร็จ: วันที่ ${game.day} • V${game.chapter} — หากเปิด Cloud Save ระบบจะพยายามซิงก์ข้อมูลตามเงื่อนไขบัญชี`);
   }catch(e){say('นำเข้า Save ไม่สำเร็จ: '+(e?.message||'ไฟล์ไม่ถูกต้อง'));}
 }
 $('he-backup-export').addEventListener('click',exportSave);
 $('he-backup-import').addEventListener('click',()=>$('he-backup-file').click());
 $('he-backup-file').addEventListener('change',async e=>{await importSave(e.target.files?.[0]);e.target.value='';});
 // Accessible skip-to-game link, not a decorative control.
 const skip=document.createElement('a');skip.href='#he-section-map';skip.className='he-skip-link';skip.textContent='ข้ามไปยังแผนที่เกม';document.body.prepend(skip);
 $('scene').setAttribute('role','img');$('scene').setAttribute('tabindex','0');
 $('scene').setAttribute('aria-description','ภาพแผนที่แบบไอโซเมตริก ใช้เมนูด้านล่างหรือปุ่มในหน้าเพื่อบริหารศูนย์');
 // Explicit indication when Cloud Save has not been configured.
 const cloud=window.HECloud?.getStatus?.();
 if(!cloud?.configured){
   const warning=document.createElement('p');warning.className='he-v10-2-cloud-warning';warning.textContent='Cloud Save ยังไม่เปิดใช้งาน • บันทึกในเครื่องและสำรอง JSON ได้ทันที • หากต้องการซิงก์ข้ามอุปกรณ์ให้ตั้งค่า Supabase และ Worker';
   toolbar.after(warning);
 }
 // In onboarding, Escape closes dialog; never swallow other form keyboard shortcuts.
 const tour=$('he-onboarding');
 if(tour){
   tour.addEventListener('keydown',e=>{if(e.key==='Escape')window.HealthcareUX?.closeTutorial?.();});
 }
 // Release build diagnostics for smoke tests.
 window.HealthcareQuality=Object.freeze({version:'10.2',exportSave,importSave,networkStatus});
})();
