/* Healthcare Empire V10.4: mobile-first UX. Preserves V10.3 engine, local saves, Supabase auth. */
(()=>{'use strict';
const bridge=window.HealthcareBridge, visual=window.HealthcareVisual;
if(!bridge||!visual)return;
const $=id=>document.getElementById(id);
const mobile=matchMedia('(max-width:760px), (max-width:980px) and (orientation:landscape)');
const mapPanel=$('scene').closest('.panel');
const stats=[['💰 เงินสด','cash'],['🛏️ ผู้พักอาศัย','residents'],['💚 คุณภาพชีวิต','wellbeing']];
const hud=document.createElement('section');hud.className='he-mob-hud';hud.setAttribute('aria-label','สถานะศูนย์ดูแล');
stats.forEach(([label,id])=>{const cell=document.createElement('div');cell.className='he-hud-stat';cell.innerHTML=`<small>${label}</small><strong data-metric="${id}">—</strong>`;hud.append(cell);});
const tools=document.createElement('div');tools.className='he-mob-tools';tools.innerHTML='<span class="he-clock" id="he-mobile-clock">Day 1</span><div style="display:flex;gap:6px"><button type="button" id="he-mobile-tour" aria-label="วิธีเล่น">❔</button><button type="button" id="he-mobile-save" aria-label="บันทึกเกม">💾</button><button type="button" class="he-next" id="he-mobile-next">▶ +1 ชม.</button></div>';
const top=document.querySelector('.top');top.after(hud,tools);
$('he-mobile-tour').addEventListener('click',()=>$('he-tour-open')?.click());
$('he-mobile-save').addEventListener('click',()=>$('save')?.click());
$('he-mobile-next').addEventListener('click',()=>document.querySelector('[data-tick="1"]')?.click());
const sheet=document.createElement('section');sheet.className='he-mob-sheet';sheet.id='he-mobile-sheet';sheet.setAttribute('role','dialog');sheet.setAttribute('aria-modal','true');sheet.setAttribute('aria-label','เมนูบริหารเกม');sheet.setAttribute('aria-hidden','true');sheet.innerHTML='<div class="he-sheet-head"><strong id="he-sheet-title">เมนู</strong><button id="he-sheet-close" type="button" aria-label="ปิดเมนู">×</button></div><div class="he-sheet-content" id="he-sheet-content"></div>';
const shade=document.createElement('div');shade.className='he-mob-shade';shade.id='he-mob-shade';shade.hidden=true;
const nav=document.createElement('nav');nav.className='he-mob-nav';nav.setAttribute('aria-label','เมนูหลักสำหรับมือถือ');
const sections=[['map','🗺️','แผนที่'],['build','🏗️','สร้าง'],['team','👩‍⚕️','บุคลากร'],['tasks','🎯','ภารกิจ'],['more','☰','เพิ่มเติม']];
sections.forEach(([id,icon,label])=>{const b=document.createElement('button');b.type='button';b.dataset.tab=id;b.innerHTML=`<span aria-hidden="true">${icon}</span>${label}`;b.setAttribute('aria-label',label);b.addEventListener('click',()=>activate(id));nav.append(b);});
document.body.append(shade,sheet,nav);
const content=$('he-sheet-content');
const panels={operations:$('buildings')?.closest('.panel'),care:$('care-actions')?.closest('.panel'),growth:$('chapters')?.closest('.panel'),finance:$('finance')?.closest('.panel'),goals:$('he-goals'),log:$('log')?.closest('.panel')};
const anchors=new Map();for(const [k,p] of Object.entries(panels)){if(p){const a=document.createComment('v10.4-'+k);p.before(a);anchors.set(p,a);}}
const gallery=document.querySelector('.he-gallery'),characters=document.querySelector('.he-gallery + .he-gallery');
for(const el of [gallery,characters]){if(el){const a=document.createComment('v10.4-gallery');el.before(a);anchors.set(el,a);}}
let current='map',lastFocus=null;
function relocate(){if(mobile.matches){for(const el of anchors.keys())content.append(el);}else{close();for(const [el,a] of anchors){a.after(el);el.hidden=false;}}}
function close(){sheet.classList.remove('he-open');shade.classList.remove('he-open');shade.hidden=true;sheet.setAttribute('aria-hidden','true');document.body.classList.remove('he-sheet-visible');lastFocus?.focus?.();}
function activate(id){current=id;nav.querySelectorAll('button').forEach(b=>b.setAttribute('aria-current',String(b.dataset.tab===id)));
 if(id==='map'){close();mapPanel.scrollIntoView({block:'start',behavior:'smooth'});return;}
 lastFocus=document.activeElement;content.scrollTop=0;
 const titles={build:'ก่อสร้างและขยายศูนย์',team:'บริหารบุคลากรและผู้พักอาศัย',tasks:'ภารกิจและการเติบโต',more:'จัดการเกมและบัญชี'};
 $('he-sheet-title').textContent=titles[id];
 for(const el of anchors.keys())el.hidden=true;
 content.querySelectorAll('.he-sheet-jump,.he-sheet-shortcuts').forEach(el=>el.remove());
 const show=(...els)=>els.forEach(el=>{if(el)el.hidden=false;});
 if(id==='build')show(panels.operations);
 if(id==='team'){show(panels.operations);const target=$('staff-actions');if(target){const jump=document.createElement('div');jump.className='he-sheet-jump';jump.innerHTML='<button type="button">ข้ามไปที่รับสมัครบุคลากร ↓</button>';jump.querySelector('button').onclick=()=>target.scrollIntoView({block:'start',behavior:'smooth'});content.prepend(jump);}}
 if(id==='tasks')show(panels.goals,panels.care,panels.growth);
 if(id==='more'){
  show(panels.finance,panels.log,gallery,characters);
  const actions=document.createElement('div');actions.className='he-sheet-jump he-sheet-shortcuts';
  for(const [label,action] of [['☁️ บัญชี', 'account-open'],['💾 Save','save'],['📤 สำรองข้อมูล','he-backup-export'],['📥 นำเข้า','he-backup-import']]){
   const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=()=>{close();$(action)?.click();};actions.append(b);
  }content.prepend(actions);
 }
 sheet.classList.add('he-open');shade.hidden=false;shade.classList.add('he-open');sheet.setAttribute('aria-hidden','false');document.body.classList.add('he-sheet-visible');$('he-sheet-close').focus();
}
$('he-sheet-close').onclick=close;shade.onclick=close;
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&sheet.classList.contains('he-open'))close();});
mobile.addEventListener('change',relocate);relocate();nav.querySelector('[data-tab="map"]').setAttribute('aria-current','true');
function updateHUD(){for(const [,id] of stats){const original=$(id),dest=hud.querySelector(`[data-metric="${id}"]`);if(original&&dest)dest.textContent=original.textContent;}$('he-mobile-clock').textContent=$('clock')?.textContent||'Day 1';}
updateHUD();const cash=$('cash');if(cash)new MutationObserver(updateHUD).observe(cash,{childList:true,subtree:true,characterData:true});
window.addEventListener('healthcare:changed',updateHUD);
// Map controls: pinch / drag / wheel on concept-art viewport, with tap targets kept in the same transformed layer.
const stage=$('he-art-stage');if(stage){
 const layer=document.createElement('div');layer.className='he-zoom-layer';layer.style.cssText='position:absolute;inset:0;transform-origin:center center;will-change:transform';
 const img=$('he-art-image');layer.append(img);stage.prepend(layer);
 const observer=new MutationObserver(()=>{for(const pin of [...stage.querySelectorAll(':scope > .he-pin')])layer.append(pin);});observer.observe(stage,{childList:true});
 for(const pin of [...stage.querySelectorAll(':scope > .he-pin')])layer.append(pin);
 const ctr=document.createElement('div');ctr.className='he-map-tools';ctr.innerHTML='<button type="button" aria-label="ขยายแผนที่" data-zoom="in">+</button><button type="button" aria-label="ย่อแผนที่" data-zoom="out">−</button><button type="button" aria-label="คืนค่ามุมมอง" data-zoom="reset">⌖</button>';stage.append(ctr);
 let scale=1,x=0,y=0;const pointers=new Map();let pinch=null,last=null;
 function paint(){const maxX=stage.clientWidth*(scale-1)/2,maxY=stage.clientHeight*(scale-1)/2;x=Math.max(-maxX,Math.min(maxX,x));y=Math.max(-maxY,Math.min(maxY,y));layer.style.transform=`translate(${x}px,${y}px) scale(${scale})`;}
 function zoomTo(next){scale=Math.max(1,Math.min(3.5,next));if(scale===1){x=0;y=0;}paint();}
 ctr.onclick=e=>{const b=e.target.closest('[data-zoom]');if(!b)return;const mode=b.dataset.zoom;zoomTo(mode==='reset'?1:scale*(mode==='in'?1.3:1/1.3));};
 stage.addEventListener('wheel',e=>{if(!mobile.matches)return;e.preventDefault();zoomTo(scale*(e.deltaY<0?1.12:1/1.12));},{passive:false});
 stage.addEventListener('pointerdown',e=>{if(!mobile.matches||e.target.closest('button'))return;stage.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});last={x:e.clientX,y:e.clientY};if(pointers.size===2){const [a,b]=[...pointers.values()];pinch={dist:Math.hypot(a.x-b.x,a.y-b.y),scale};}stage.classList.add('he-dragging');});
 stage.addEventListener('pointermove',e=>{if(!pointers.has(e.pointerId))return;const old=pointers.get(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size===2&&pinch){const [a,b]=[...pointers.values()];zoomTo(pinch.scale*Math.hypot(a.x-b.x,a.y-b.y)/Math.max(1,pinch.dist));}else if(scale>1){x+=e.clientX-old.x;y+=e.clientY-old.y;paint();}});
 const end=e=>{pointers.delete(e.pointerId);if(pointers.size<2)pinch=null;if(!pointers.size)stage.classList.remove('he-dragging');};stage.addEventListener('pointerup',end);stage.addEventListener('pointercancel',end);
 window.HealthcareMobile={version:'10.4',open:activate,close,zoom:zoomTo};
}
})();
